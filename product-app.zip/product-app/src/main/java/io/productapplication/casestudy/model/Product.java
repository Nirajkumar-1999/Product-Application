package io.productapplication.casestudy.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Document(collection="products")
public class Product {
	
	@Id
	private String id;
	
	@NotBlank(message="Product name cannot be blank")
	private String productName;
	
	@NotNull(message="Cost cannot be Null")
	private int cost;
	
	private String description;
	
	public Product() {
		
	}
	


	public Product(String id, @NotBlank(message = "Product name cannot be blank") String productName,
			@NotNull(message = "Cost cannot be Null") int cost, String description) {
		super();
		this.id = id;
		this.productName = productName;
		this.cost = cost;
		this.description = description;
	}



	public String getId() {
		return id;
	}
	
	
	public void setId(String id) {
		this.id = id;
	}
	
	
	public String getProductName() {
		return productName;
	}
	
	
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	public int getCost() {
		return cost;
	}
	
	
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	
	public String getDescription() {
		return description;
	}
	
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
