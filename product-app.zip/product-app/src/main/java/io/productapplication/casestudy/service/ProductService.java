package io.productapplication.casestudy.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;


import io.productapplication.casestudy.model.Product;

@Service
public class ProductService {
	
	private List<Product> products = Arrays.asList(
			new Product("14589","T-shirt",220,"Buy one get one free"),
			new Product("28765","Jeans",780,"20% dicount on two items"),
			new Product("74532","jackets",999,"Buy two get one free")
			);
	
	
	public List<Product> getAllProduct(){
		return products;
	}
	
	public Product getProduct(String id) {
		return products.stream().filter(x -> x.getId().equals(id)).findFirst().get();
	}
	
	public void addProduct(Product product) {
		products.add(product);
	}
	
	public void updateProduct(String id, Product product) {
		for(int i=0; i<products.size();i++) {
			Product p = products.get(i);
			if(p.getId().equals(id)) {
				products.set(i, product);
				return;
			}
		}
	}
	
	public void deleteProduct(String id) {
		products.removeIf(x -> x.getId().equals(id));
	}

}
